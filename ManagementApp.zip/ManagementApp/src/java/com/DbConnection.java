/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

/**
 *
 * @author DELL
 */
import java.sql.*;
public class DbConnection {
    Connection c=null;
    Statement st=null;
    ResultSet rs=null;
    public DbConnection(){
    try{
        Class.forName("com.mysql.jdbc.Driver");
        c=DriverManager.getConnection("jdbc:mysql://localhost:3306/managementapp","root","root");
        st=c.createStatement();
    
}
    catch(Exception e){
        System.out.println(e);
    }
    }
    public int logcheck(String uname,String pswd){
        int count=0;
        try{
        String sql="select * from login where username='"+uname+"' and pasword='"+pswd+"'";
            System.out.println(sql);
        rs=st.executeQuery(sql);
        while(rs.next()){
        count++;
        }
        if(count>0){
            System.out.println("yes");
        }
        else{
            System.out.println("nop");
        }
        }catch(Exception e){
            System.out.println(e);
        }
        
        return count;
        
    
    }
    public int AddProduct(String dt,String code,String name,int price,int stoke){
        int i=0;
        try{
            String sql="insert into product(createOn,code,name,price,stoke)values('"+dt+"','"+code+"','"+name+"',"+price+","+stoke+")";
            i=st.executeUpdate(sql);
        }
        catch(Exception e){
            System.out.println(e);
        }
        return i;
    
    
    }
    public ResultSet ViewProducts(){
        try{
        String sql="select * from product";
        rs=st.executeQuery(sql);
        }
        catch(Exception e){
            System.out.println(e);
        }
        return rs;
    
    }
    public int deleteProduct(String product){
        int i=0;
        try{
        String sql="delete from product where name='"+product+"'";
        i=st.executeUpdate(sql);
        }
        catch(Exception e){
            System.out.println(e);
        }
        return i;
        
    
    }
    public int percentageDiscount(String code,String start,String end,int price){
        int i=0;
        try{
            String sql="update product set price="+price+" where code='"+code+"' and createOn between '"+start+"' and '"+end+"'";
            i=st.executeUpdate(sql);
            
        
        }
        catch(Exception e){
            System.out.println(e);
        }
        
        return i;
    
    }
     public ResultSet View(String code){
        try{
        String sql="select * from product where code='"+code+"'";
        rs=st.executeQuery(sql);
        }
        catch(Exception e){
            System.out.println(e);
        }
        return rs;
    
    }
    
    
}
